import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditTasksComponent } from './components/edit-tasks/edit-tasks/edit-tasks.component';
import { TasksComponent } from './components/tasks/tasks/tasks.component';

const routes: Routes = [
  {path: "", redirectTo: "/tasks", pathMatch: "full"},
  {path: "tasks", component: TasksComponent},
  {path: "edit", component: EditTasksComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
