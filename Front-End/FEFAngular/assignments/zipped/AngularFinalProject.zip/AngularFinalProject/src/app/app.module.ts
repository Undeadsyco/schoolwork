import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { NavComponent } from './shared/components/nav/nav.component';
import { TasksModule } from './components/tasks/tasks.module';
import { EditTasksModule } from './components/edit-tasks/edit-tasks.module';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TasksModule,
    EditTasksModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
