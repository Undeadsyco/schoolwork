import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EditTasksComponent } from './edit-tasks/edit-tasks.component';
import { TaskDataService } from '../services/task-data.service';



@NgModule({
  declarations: [EditTasksComponent],
  imports: [
    CommonModule,
    FormsModule,
  ],
  providers: [TaskDataService],
  exports: [EditTasksComponent]
})
export class EditTasksModule { }
