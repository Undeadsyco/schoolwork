import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from 'src/app/shared/models/task';
import { TaskDataService } from '../../services/task-data.service';

@Component({
  selector: 'app-edit-tasks',
  templateUrl: './edit-tasks.component.html',
  styleUrls: ['./edit-tasks.component.css']
})
export class EditTasksComponent implements OnInit {

  tasks: Task[];
  newTask: Task = new Task();

  getTasks(): void{
    this.taskDataService.getTasks().subscribe(ucTasks => (this.tasks = ucTasks))
  }

  onClickAdd(){
    this.taskDataService.onClickAdd(this.newTask).subscribe(
      ucTask =>
      this.router.navigate(["tasks"])
    )
  }
  edit(id: number ,name: string, discription: string, isComplete: boolean){
    this.newTask = {"id":id, "name": name, "discription": discription, "isComplete": isComplete}
  }

  onClickDelete(id: number){
    this.taskDataService.onClickDelete(id).subscribe(ucTasks => this.getTasks());
  }

  onClickEdit(id:number, name: string, discription: string, isComplete){
    this.onClickDelete(id);
    this.edit(id, name, discription, isComplete)
  }

  constructor(private taskDataService: TaskDataService, private router: Router) { }

  ngOnInit(): void {
    this.getTasks()
  }

}
