import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Task } from '../../shared/models/task';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TaskDataService {
  url: string ="http://localhost:3000/tasks"

  getTasks(): Observable<Task[]>{
    return this.http.get<Task[]>(this.url);
  }

  onClickAdd(task: Task): Observable<Task>{
    return this.http.post<Task>(this.url, task);
  }

  onClickDelete(id: number): Observable<Task>{
    return this.http.delete<Task>(this.url + "/" +id);
  }
  
  constructor(private http: HttpClient) { }
}
