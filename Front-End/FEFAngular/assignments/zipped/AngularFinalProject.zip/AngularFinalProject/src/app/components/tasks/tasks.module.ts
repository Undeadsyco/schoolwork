import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { TasksComponent } from './tasks/tasks.component';



@NgModule({
  declarations: [TasksComponent],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  exports: [TasksComponent]
})
export class TasksModule { }
