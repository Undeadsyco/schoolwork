import { Component, OnInit } from '@angular/core';
import { Task } from 'src/app/shared/models/task';
import { TaskDataService } from '../../services/task-data.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  tasks: Task[];

  getTasks(): void{
    this.taskDataService.getTasks().subscribe(ucTasks => (this.tasks = ucTasks))
  }

  constructor(private taskDataService: TaskDataService) { }

  ngOnInit(): void {
    this.getTasks()
  }
}
