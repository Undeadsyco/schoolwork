export class Task {
    id: number;
    name: string;
    discription: string;
    isComplete: boolean;
}
