import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Brandon';
  city = "wichita, KS";
  Tagline = "Working hard everyday, and learn something extra along the way.";
  Aboutme = "I'm currently working as an assisstant manager, while learning fullstack coding to eventually start a new career."
}
