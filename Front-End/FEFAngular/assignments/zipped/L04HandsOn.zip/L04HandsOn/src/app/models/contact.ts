export class Contact {
    name: string;
    phoneNumber: string;
    email: string;

}
