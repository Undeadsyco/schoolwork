export class Music{
    id: number;
    title: string;
    artist: string;
    video_url: string;
}