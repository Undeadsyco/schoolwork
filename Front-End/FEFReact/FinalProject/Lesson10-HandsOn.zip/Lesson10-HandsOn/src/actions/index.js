export const increment = () => ({
  type: 'INCREMENT'
});

export const decrement = () => ({
  type: 'DECREMENT'
});

export const change = (addAmount) => ({
  type: 'CHANGE',
  addAmount
})

export const addAmount = () => ({
  type: 'ADDAMOUNT'
});

